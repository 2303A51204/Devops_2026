function Profile() {
  return (
    <div className="page">
      <h2>Profile</h2>
      <div className="profile-info">
        <p><strong>Name:</strong> John Doe</p>
        <p><strong>Roll No:</strong> 12345</p>
        <p><strong>Department:</strong> Computer Science</p>
        <p><strong>Email:</strong> johndoe@email.com</p>
      </div>
    </div>
  );
}

export default Profile;
