function Courses() {
  return (
    <div className="page">
      <h2>Courses</h2>
      <ul className="course-list">
        <li>Mathematics</li>
        <li>Computer Science</li>
        <li>Physics</li>
        <li>English Literature</li>
      </ul>
    </div>
  );
}

export default Courses;
