function Dashboard() {
  return (
    <div className="page">
      <h2>Student Dashboard</h2>
      <p>Welcome back! Here's a quick overview of your performance.</p>

      <div className="stats">
        <div className="card">Attendance: 92%</div>
        <div className="card">GPA: 3.7</div>
        <div className="card">Completed Credits: 84</div>
      </div>
    </div>
  );
}

export default Dashboard;
