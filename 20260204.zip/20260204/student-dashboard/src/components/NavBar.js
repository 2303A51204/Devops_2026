import { NavLink } from "react-router-dom";
import "./NavBar.css";

function NavBar() {
  return (
    <nav className="navbar">
      <NavLink
        to="/"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Dashboard
      </NavLink>

      <NavLink
        to="/courses"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Courses
      </NavLink>

      <NavLink
        to="/profile"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Profile
      </NavLink>
    </nav>
  );
}

export default NavBar;
